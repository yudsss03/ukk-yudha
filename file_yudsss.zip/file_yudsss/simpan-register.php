<?php 
include('koneksi.php');
$nama_lengkap = $_POST['nama_lengkap'];
$username = $_POST['username'];
$password = md5($_password['password']);
$query = "INSERT INTO `masyarakat` (`nama_lengkap`, `username`, `password`) VALUES ('$nama_lengkap','$username','$password')";
if($connection->query($query)){
    echo 'berhasil';
} else {
    echo 'gagal';
}
?>