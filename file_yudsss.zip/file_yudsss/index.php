<?php 
@header('location: modul/modul-auth');
?>