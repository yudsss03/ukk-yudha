<?php
include('koneksi.php');
// $nama_lengkap = $_POST['nama_lengkap'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$query = "SELECT * FROM masyarakat WHERE username='$username' AND password='$password'";
$result - mysqli_result($query);

?>




