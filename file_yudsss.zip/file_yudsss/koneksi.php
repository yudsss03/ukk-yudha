<?php 

$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'db_pengaduan_masyarakat';

$connection = mysqli_connect($db_host, $db_username);

if ($connection){
    // echo 'p';
} else {
    echo 'gagal';
}

?> 